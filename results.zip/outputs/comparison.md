# Before vs After (same prompts, greedy decoding)

## Prompt: How do airplanes fly?

**Base model:**

Airplanes fly using special machines called propellers that spin around a central shaft. They move through the air by pushing against it with their wings, which are shaped like small fans. This creates lift, allowing the airplane to soar high into the sky!

**Fine-tuned model:**

Short answer: Airplanes fly by making a big circle and then letting the air rush out to make them go faster.

Example: When you blow into a straw, it makes the air rush out of your mouth so that you can breathe better.

Remember: The bigger the airplane is, the more powerful it needs to be to lift off the ground.

---

## Prompt: What is a firewall?

**Base model:**

A firewall is like a strong barrier that keeps bad things from entering your computer or network, just like a gatekeeper keeps out unwanted visitors. It's made to protect your computer and keep it safe from hackers or other malicious people trying to harm you.

**Fine-tuned model:**

Short answer: A firewall is a computer program that keeps your internet safe by checking incoming and outgoing traffic to make sure it's not bad.

Example: Think of it like a security guard at the door who checks every visitor before letting them inside, just like a real firewall does on your computer network.

Remember: Firewalls help protect you from hackers and other bad people trying to break into your online world.

---

## Prompt: Why is the sky blue?

**Base model:**

The sky appears blue because it reflects sunlight, which has different colors depending on its wavelength. The blue light from the sun gets absorbed by the Earth's atmosphere, making it appear as blue. This phenomenon is called Rayleigh scattering.

**Fine-tuned model:**

Short answer: The sky is blue because it reflects sunlight.

Example: When you look at a clear blue sky, all the colors of the rainbow come together to make the bright blue light that we see.

Remember: Sunlight makes the sky appear blue because it bounces off tiny water droplets in the air and mixes with the Earth's atmosphere.

---

## Prompt: What is an operating system?

**Base model:**

An operating system is like the brain of a computer, managing all its tasks and functions. It's what tells your computer to do things like open programs, save work, and run other software. Think of it as the main boss that keeps everything running smoothly!

**Fine-tuned model:**

Short answer: An operating system is the main computer program that runs on your computer to make it work.

Example: Think of it like a teacher who controls all the computers in your school so they can play games and share files, even if you don't have a keyboard or mouse.

Remember: Without an operating system, your computer would be just a bunch of buttons and switches.

---

## Prompt: How do earthquakes happen?

**Base model:**

Earthquakes happen when there's a sudden movement of tectonic plates on the Earth's surface. Imagine you're building with blocks, and one block falls down. That's like an earthquake! The blocks keep falling because they're stuck together, but now they're moving apart. This is what we call shaking or trembling. It can be really big and cause damage, but it usually happens slowly over time.

**Fine-tuned model:**

Short answer: Earthquakes happen when the tectonic plates on the ground move and shift.

Example: Think of a giant rubber band stretched out, like a playground slide. When you push it hard, it snaps back into place, just like an earthquake does to rocks under the surface.

Remember: The big movement is called a fault line, and the shaking is felt far away because it's so strong.

---

## Prompt: What is GDP?

**Base model:**

GDP stands for Gross Domestic Product, which measures the total value of all goods and services produced within a country's borders in a specific time period. It helps us understand how much money people spend on things they buy and sell.

**Fine-tuned model:**

Short answer: GDP measures the total value of all goods and services produced in a country over a certain period.

Example: It's like counting how many toys you bought at the store, but for every toy, it includes everything from paper to plastic to even your own clothes.

Remember: GDP tells us how much money people have in their pockets today compared to what they had before.

---

## Prompt: What is a variable in programming?

**Base model:**

In programming, a variable is like a box where you can put different values. Think of it as a container that holds information or data. You can change the value inside this box whenever you want to use it later. For example, if you have a variable called "name," you could set its value to "John" and then change it to "Jane" at any point during your program's execution. This allows programs to store and access various pieces of information based on what they need.

**Fine-tuned model:**

Short answer: A variable is a special place in your computer where you can store information that changes over time.

Example: Think of it like a secret code for storing the number 5, and then adding or subtracting numbers to change it every time you type something into your calculator.

Remember: Variables help you keep track of different values so you don't have to remember them all at once.

---

## Prompt: How do noise-cancelling headphones work?

**Base model:**

Noise-cancelling headphones use special technology to block unwanted sounds while letting the music through. They work by using tiny microphones that pick up sound waves and send them to a speaker. The headphones then filter out any unwanted noises, making it easier for you to listen to your favorite songs without background noise. This helps people who have trouble with loud environments or noisy places.

**Fine-tuned model:**

Short answer: Noise-cancelling headphones use tiny microphones to pick up sound and then send it through a special filter that cancels out unwanted sounds.

Example: Think of them like a giant earpiece that blocks out the outside world, so you can hear your music without any background noise.

Remember: These headphones help you listen better by blocking out all the other noises around you.

---
